/* qwebirc -- Copyright (C) 2008-2012 Chris Porter and the qwebirc project --- All rights reserved. */

